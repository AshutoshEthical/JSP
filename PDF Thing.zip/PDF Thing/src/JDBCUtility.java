import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.driver.OracleDriver;

public class JDBCUtility {
	
	static Connection connection =null;
	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String USERNAME="system";
	final static String PASSWORD="Capgemini123";
	
	public static Connection getConnection() throws SQLException
	{
		try {
			DriverManager.registerDriver(new OracleDriver());
			connection=DriverManager.getConnection(URL,USERNAME,PASSWORD);
			return connection;
			
		} catch(SQLException e) {
			
			throw new SQLException();
		}
		//return connection;
	}
}
