import java.awt.print.PageFormat;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class pdf {
	 static Connection connection =null;
	static PreparedStatement statement=null;
	
	public static void main(String[] args) {
		Document doc = new Document(PageSize.A4, 100,100,100,100);
		ResultSet rs= null;
		try
	      {
			connection =JDBCUtility.getConnection();
			statement=connection.prepareStatement("select * from userrole");
	        rs=statement.executeQuery();
			PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("D:\\ashutosh1.pdf"));
	         doc.open();
	        
	         Anchor at = new Anchor("For the first Time!!");
	         at.setName("Back to top");
	         Paragraph para1 = new Paragraph();
	         para1.setSpacingAfter(50);
	         para1.add(at);
	         doc.add(para1);
	         
	         
	         PdfPTable table = new PdfPTable(3);
	         table.setSpacingBefore(50);
	         table.setSpacingAfter(50);
	         
	         PdfPCell c1= new PdfPCell(new Phrase("username"));
	         table.addCell(c1);
	         
	         PdfPCell c2= new PdfPCell(new Phrase("password"));
	         table.addCell(c2);
	         
	         PdfPCell c3= new PdfPCell(new Phrase("rolecode"));
	         table.addCell(c3);
	         
	         while(rs.next())
	         {
	        	 String s1= rs.getString(1);
	        	 String s2= rs.getString(2);
	        	 String s3= rs.getString(3);
	        	 table.addCell(s1);
	        	 table.addCell(s2);
	        	 table.addCell(s3);
	         }
	         doc.add(table);
	         
	         doc.close();
	         writer.close();
	         System.out.println("Process Completed");
	      } catch (DocumentException e)
	      {
	         e.printStackTrace();
	      } catch (FileNotFoundException e)
	      {
	         e.printStackTrace();
	      }catch(SQLException e) {
	    	  e.printStackTrace();
	      }
	}
}
