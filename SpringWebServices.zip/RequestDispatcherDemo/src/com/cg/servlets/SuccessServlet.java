package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/success")
public class SuccessServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	PrintWriter writer = resp.getWriter();
	writer.print("<html><body>");
	
	String name=req.getParameter("uname");
	writer.println("<h1><font color='green'>Login Success Me:"+name+"</font></h1><br>");
	writer.println("<h2><a href='home'>Click for home page</a></h2>");
	writer.print("</body><html");
	}
}
