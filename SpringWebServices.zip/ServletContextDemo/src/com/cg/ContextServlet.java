package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jdbc.driver.OracleDriver;

@WebServlet("/test")

/*@WebServlet(
		urlPatterns="/test",
		initParams= {
				@WebInitParam(name="url",value="jdbc:oracle:thin:@localhost:1521:XE"),
				@WebInitParam(name="username",value="system"),
				@WebInitParam(name="password",value="Capgemini123")
		})
*/public class ContextServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	ServletContext context = getServletContext();

	PrintWriter out= response.getWriter();
	
	String dbUrl=context.getInitParameter("url");
	String dbUname=context.getInitParameter("username");
	String dbPassword=context.getInitParameter("password");
	
	
	try 
	{
		DriverManager.registerDriver(new OracleDriver());
		Connection connection=DriverManager.getConnection(dbUrl,dbUname,dbPassword);
		out.println("<html><body>");

		out.println("<a href='mytest'>Click</a>");
		out.println("Connected to Db");
		out.println("<a href='mytest'>Click</a>");
		out.println("</body></html>");
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	
	
	
	}

}
